export enum CardTypeEnum {
  AMERICAN_EXPRESS = 'American Express',
  MAESTRO = 'Maestro',
  MASTERCARD = 'Mastercard',
  VISA_ELECTRON = 'Visa Electron',
  VISA = 'VISA',
}
