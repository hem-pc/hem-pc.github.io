export interface CardModel {
  cardNumber: string;
  cardHolder: string;
  expirationMonth: string;
  expirationYear: string;
  ccv: number;
}
